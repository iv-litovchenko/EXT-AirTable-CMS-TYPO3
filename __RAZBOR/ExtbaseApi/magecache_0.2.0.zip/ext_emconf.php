<?php

$EM_CONF[$_EXTKEY] = array(
	"title" => "MageDeveloper Cache & Session ViewHelpers",
	"description" => "This extension offers ViewHelpers for caching and session data handling.",
	"category" => "plugin",
	"shy" => 0,
	"version" => "0.2.0",
	"dependencies" => "cms,extbase,fluid",
	"conflicts" => "",
	"priority" => "",
	"loadOrder" => "",
	"module" => "",
	"state" => "beta",
	"uploadfolder" => 0,
	"modify_tables" => "",
	"clearcacheonload" => 1,
	"lockType" => "",
	"author" => "Bastian Zagar",
	"author_email" => "zagar@aixdesign.net",
	"author_company" => "aixdesign.net",
	"CGLcompliance" => "",
	"CGLcompliance_note" => "",
	"constraints" => array(
		"depends" => array(
			"typo3" => "6.2.0-7.6.99",
		),
		"conflicts" => array(
		),
		"suggests" => array(
		),
	),
	"_md5_values_when_last_written" => "a:0:{}",
	"suggests" => array(
	),
);
