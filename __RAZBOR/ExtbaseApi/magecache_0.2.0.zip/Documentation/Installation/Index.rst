.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _installation:

Installation
------------

Adding Static to your template
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

You can include static to your template in order to set a global lifetime for your caches.
Just add "Extension 'MageCache' (magecache)" to your template static like shown in the following picture.


.. image:: ../Images/adding_static.jpg


Changing the default lifetime
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The global lifetime of the caches is configured in the Typoscript. You can refer to the constants to change the lifetime setting
like shown in the picture below.


.. image:: ../Images/constants.jpg


Another way is to directly change the Typoscript Setup with

::
	
	plugin.tx_magecache.settings.cache_lifetime = XXX

