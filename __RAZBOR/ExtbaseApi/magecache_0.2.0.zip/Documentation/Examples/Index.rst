.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _examples:

Examples
--------

Multi level caching
^^^^^^^^^^^^^^^^^^^

You can use the Caching ViewHelper multiple times in your template, but notice that lifetime differences
can also return a cached result.

::

    <c:cache hash="magecache-hash" lifetime="30">
        Cached content!
        <c:cache hash="second-cache" lifetime="5">
            This is a second 'cached' element :)
        </c:cache>
    </c:cache>

Location-independent caching
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Setting the cache:
~~~~~~~~~~~~~~~~~~

::
	    
    <c:cache hash="magecache-hash" lifetime="30" silent="1">
        <strong>THIS IS THE CACHED CONTENT</strong>
    </c:cache>

Getting the cache:
~~~~~~~~~~~~~~~~~~

::

	<c:cache.get hash="magecache-hash" />

Flux Flexible Cache Content Element
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

::
	
	<div xmlns="http://www.w3.org/1999/xhtml" lang="en"
        xmlns:f="http://typo3.org/ns/TYPO3/Fluid/ViewHelpers"
        xmlns:flux="http://typo3.org/ns/FluidTYPO3/Flux/ViewHelpers"
        xmlns:c="http://typo3.org/ns/MageDeveloper/Magecache/ViewHelpers"
        xmlns:v="http://typo3.org/ns/FluidTYPO3/Vhs/ViewHelpers">
	    <f:layout name="Content" />
	    <f:section name="Configuration">
	        <flux:form id="cache_box"
	                   wizardTab="Templates"
	                   label="Cache Box"
	                   description="Caches content elements withing this box.">
	            <flux:grid>
	                <flux:grid.row>
	                    <flux:grid.column name="content" label="Content Elements"></flux:grid.column>
	                </flux:grid.row>
	            </flux:grid>
	        </flux:form>
	    </f:section>
	    <f:section name="Preview"></f:section>
	    <f:section name="Main">
	        <c:cache hash="magecache-cache-{page.uid}-{record.uid}">{flux:content.render(area:'content')}</c:cache>
	    </f:section>
	</div>    