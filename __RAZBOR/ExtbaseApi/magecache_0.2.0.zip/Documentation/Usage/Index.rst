.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _usage:

Usage
-----

Main Cache ViewHelper
^^^^^^^^^^^^^^^^^^^^^
If you've included the Namespace into your template, you can access the Cache-Viewhelper as following
::

    <c:cache>
        <!-- YOUR CONTENT TO BE CACHED -->
    </c:cache>

Arguments
+++++++++
+---------------------+----------+----------------------------------------------------------------------------------------------------------------------+
| ViewHelper Argument | Type     | Additional Information                                                                                               |
+=====================+==========+======================================================================================================================+
| lifetime            | int      | The cache lifetime in seconds. If you do not use this parameter, the lifetime from the Typoscript Setup is used      |
+---------------------+----------+----------------------------------------------------------------------------------------------------------------------+
| tags                | array    | Cache Tags                                                                                                           |
+---------------------+----------+----------------------------------------------------------------------------------------------------------------------+
| hash                | string   | The unique cache identifier hash. Leave this blank and the hash is automatically created                             |
+---------------------+----------+----------------------------------------------------------------------------------------------------------------------+
| silent              | bool     | If set, the cache is added without displaying the content. You can regain it by using the cache.get ViewHelper.      |
+---------------------+----------+----------------------------------------------------------------------------------------------------------------------+

(Optional) Cache Get ViewHelper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

If you enabled the "silent"-flag, the content is added in background. You can later use the following code to get the cached content
anywhere you want.

::


	<c:cache.get hash="yourhash" />

::


Priority of cache lifetime
^^^^^^^^^^^^^^^^^^^^^^^^^^
1. ViewHelper Argument "lifetime"
2. If no argument was given, the plugin.tx_magecache.settings.cache_lifetime is used
3. Default Cache Lifetime: 3600 Seconds = 60 Minutes



Cache Information in Fluid
^^^^^^^^^^^^^^^^^^^^^^^^^^


.. image:: ../Images/variable_dump.jpg


Cache Information is stored in template variables in the order of the last usage.
This means that the order is in relation to the depth of the Cache-ViewHelper usage.
The deepest element is on top of the variables array.

*All Cache Information is stored as an array (e.g. Get Information on the last usage with {cacheHash.0})*


+---------------------+-------------------------------------------------------+
| Variable            | Information                                           |
+=====================+=======================================================+
| cacheHash           | Cache Hash Identifier                                 |
+---------------------+-------------------------------------------------------+
| cacheLifetime       | Cache Lifetime in Seconds                             |
+---------------------+-------------------------------------------------------+
| cacheTags           | Cache Tags              s                             |
+---------------------+-------------------------------------------------------+
| cacheStatus         | Status of the cache (RESTORED or CACHED)              |
+---------------------+-------------------------------------------------------+




Session ViewHelpers
^^^^^^^^^^^^^^^^^^^
This extension also delivers Session-ViewHelpers for Getting/Setting Information to the FeUser-Session
You can access them by using the following code:

Setting Information to the session
++++++++++++++++++++++++++++++++++

::

    <c:session.set id="dumb-content">My Dumb Content!</c:session.set>

Obtain Information from the session
+++++++++++++++++++++++++++++++++++

::

	<c:session.get id="dumb-content" />
