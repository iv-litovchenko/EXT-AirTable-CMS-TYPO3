.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _start:

=======================
MageCache Documentation
=======================

.. only:: html

	:Language:
		en

	:Version:
		0.1.0

	:Description:
		Cache/Session ViewHelpers

	:Keywords:
		cache, caching, session, viewhelpers

	:Copyright:
		2015, aixdesign.net

	:Author:
		Bastian Zagar [aixdesign.net]

	:Email:
		zagar@aixdesign.net

	:License:
		This document is published under the Open Content License
		available from http://www.opencontent.org/opl.shtml

	:Rendered:
		|today|


Table of contents:
------------------

.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:
   
   Information/Index
   Installation/Index
   Usage/Index
   Examples/Index
		  
		   


Changelog:
~~~~~~~~~~

2016-01-11

- Added silent mode to cache ViewHelper
- Added CacheGet ViewHelper to regain cache


