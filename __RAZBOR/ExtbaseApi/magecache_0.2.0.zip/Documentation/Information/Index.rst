.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _information:

Information / Including
-----------------------

Introduction
^^^^^^^^^^^^
MageCache is a set of ViewHelpers to cache contents or get/set session data within fluid.

Including into Fluid Templates
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
To use the Cache ViewHelpers, just add the Namespace to your Fluid-Template by using
::

	<div xmlns="http://www.w3.org/1999/xhtml" lang="en"
         xmlns:f="http://typo3.org/ns/TYPO3/Fluid/ViewHelpers"
         xmlns:c="http://typo3.org/ns/MageDeveloper/Magecache/ViewHelpers">
         (Your content goes here)
	</div>


or you can use
::

	{namespace c = MageDeveloper\Magecache\ViewHelpers}
