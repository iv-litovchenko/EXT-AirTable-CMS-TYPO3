<?php
if (!defined("TYPO3_MODE")) {
	die ("Access denied.");
}

/***********************************
 * Register Cache
 ***********************************/
if (!is_array($TYPO3_CONF_VARS["SYS"]["caching"]["cacheConfigurations"]["magecache_cache"]))
{
	$TYPO3_CONF_VARS["SYS"]["caching"]["cacheConfigurations"]["magecache_cache"] 								= array();
	$TYPO3_CONF_VARS["SYS"]["caching"]["cacheConfigurations"]["magecache_cache"]["frontend"] 					= "TYPO3\\CMS\\Core\\Cache\\Frontend\\VariableFrontend";
	$TYPO3_CONF_VARS["SYS"]["caching"]["cacheConfigurations"]["magecache_cache"]["backend"] 					= "TYPO3\\CMS\\Core\\Cache\\Backend\\Typo3DatabaseBackend";
	$TYPO3_CONF_VARS["SYS"]["caching"]["cacheConfigurations"]["magecache_cache"]["options"]["compression"] 	= 1;
}
