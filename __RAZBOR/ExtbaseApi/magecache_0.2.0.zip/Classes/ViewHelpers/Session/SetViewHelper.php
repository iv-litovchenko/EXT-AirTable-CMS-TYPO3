<?php
namespace MageDeveloper\Magecache\ViewHelpers\Session;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class SetViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper
{
	/**
	 * SessionService
	 *
	 * @var \MageDeveloper\Magecache\Service\Session\SessionService
	 * @inject
	 */
	protected $sessionService;

	/**
	 * Initialize arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments()
	{
		$this->registerArgument("id", "string", "Session Value Identifier", true);

		parent::initializeArguments();
	}
	
	/**
	 * Render Method
	 *
	 * @return void
	 */
	public function render()
	{
		$content 	= $this->renderChildren();
		$id			= $this->arguments["id"];
		
		$this->sessionService->setData($id, $content);
		
		return;
	}

}