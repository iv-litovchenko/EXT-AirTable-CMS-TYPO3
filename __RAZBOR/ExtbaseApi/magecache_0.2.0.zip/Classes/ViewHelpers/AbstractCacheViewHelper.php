<?php
namespace MageDeveloper\Magecache\ViewHelpers;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
abstract class AbstractCacheViewHelper extends AbstractViewHelper
{
	/**
	 * Cache Status
	 *
	 * @var string
	 */
	const CACHE_RESTORED 	= "RESTORED";
	const CACHED			= "CACHED";

	/**
	 * @var \TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer
	 */
	protected $contentObject;

	/**
	 * @var \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface
	 */
	protected $configurationManager;

	/**
	 * @param \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface $configurationManager
	 * @return void
	 */
	public function injectConfigurationManager(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface $configurationManager)
	{
		$this->configurationManager = $configurationManager;
		$this->contentObject = $this->configurationManager->getContentObject();
	}

	/**
	 * Gets content with special cached markers
	 *
	 * @param string $content
	 * @return string
	 */
	protected function _cachedContent($content)
	{
		$cachedContent = "";
		$cachedContent .= "<!--CACHEDCONTENT_begin-->";
		$cachedContent .= $content;
		$cachedContent .= "<!--CACHEDCONTENT_end-->";

		return $cachedContent;
	}

	/**
	 * Adds information to the template variable container
	 *
	 * @param string $identifier
	 * @param string $value
	 * @return void
	 */
	protected function _addToTemplateVariableContainer($identifier, $value)
	{
		$arrForIdentifier = array();
		if ($this->templateVariableContainer->exists($identifier))
		{
			$arrForIdentifier = $this->templateVariableContainer->get($identifier);
			$this->templateVariableContainer->remove($identifier);
		}

		if(is_array($arrForIdentifier))
			$arrForIdentifier[] = $value;

		$this->templateVariableContainer->add($identifier, $arrForIdentifier);

		return;
	}
}