<?php

namespace MageDeveloper\Magecache\ViewHelpers\Cache;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class GetViewHelper extends \MageDeveloper\Magecache\ViewHelpers\AbstractCacheViewHelper
{
	/**
	 * Initialize arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments()
	{
		$this->registerArgument("hash", "string", "Cache Hash Identifier", true);
	}

	/**
	 * Render Method
	 *
	 * @return void
	 */
	public function render()
	{
		$hash = $this->arguments["hash"];
	
		// Checking if the content is already in cache
		if ($this->generalCacheService->has($hash))
		{
			// The content is already in the cache
			$this->_addToTemplateVariableContainer("cacheStatus", self::CACHE_RESTORED);
			return $this->_cachedContent( $this->generalCacheService->get($hash) );
		}
		
		return "";
	}

}