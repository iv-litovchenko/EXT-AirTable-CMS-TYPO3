<?php
namespace MageDeveloper\Magecache\ViewHelpers;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
use TYPO3\CMS\Fluid\Core\Rendering\RenderingContextInterface;

/**
 * --------------------------------------------------------------------------------------------------------------
 * Class CacheViewHelper
 * --------------------------------------------------------------------------------------------------------------
 * 
 * @package MageDeveloper\Magecache\ViewHelpers
 * 
 * This view helper caches content from the children in it
 * How to use it:
 * 
 * {namespace c = MageDeveloper\Magecache\ViewHelpers}
 * 
 * <c:cache lifetime="60">
 * 		<h1>Inner Content that will be cached</h1>
 * 		<f:for each="{items}" as="item">
 * 			Item #{item.id}
 * 		</f:for>
 * </c:cache>
 * 
 * Quick with default lifetime:
 * 
 * <c:cache>content</c:cache>
 * 
 * The template variable container will have several information items AFTER each
 * cache view helper is used:
 * 
 * {cacheStatus} 		- 	array 			- Each view helper call will add an status to this template variable
 * {cacheHash}			-	array			- Each cache hash
 * {cacheLifetime}		-	array			- Each cache lifetime
 * {cacheTags}			-	array			- Each cache tags as an array
 * 
 */ 
class CacheViewHelper extends \MageDeveloper\Magecache\ViewHelpers\AbstractCacheViewHelper
{
	/**
	 * Initialize arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments()
	{
		$this->registerArgument("lifetime", "int", "Custom Cache Lifetime", false, null);
		$this->registerArgument("tags", "array", "Cache Tags", false, array());
		$this->registerArgument("hash", "string", "Custom Cache Hash", false, null);
		$this->registerArgument("silent", "bool", "Silent Cache creation", false, false);
		
		parent::initializeArguments();
	}

	/**
	 * Gets the cache lifetime that was set
	 * between the view helper settings or the
	 * template configuration
	 * 
	 * @return int
	 */
	protected function _getCacheLifetime()
	{
		if (isset($this->arguments["lifetime"]))
			return (int)$this->arguments["lifetime"];
		
		if ($lifetime = $this->cacheSettingsService->getCacheLifetime())
			return (int)$lifetime;
			
		return \MageDeveloper\Magecache\Service\Cache\CacheService::DEFAULT_CACHE_LIFETIME;
	}

	/**
	 * Render Method
	 *
	 * @return void
	 */
	public function render()
	{
		// Caching settings
		$lifetime 			= $this->_getCacheLifetime();
		$tags				= $this->arguments["tags"];
		
		// Content & Id
		$cacheContent 		= $this->renderChildren();
		$hash				= $this->hashService->generateHmac($cacheContent);
		
		if (!$cacheContent || strlen($cacheContent) === false)
			return;
		
		// Render damn INT_SCRIPT :P / Rendering plugin html
		/**************************************************************/
		/* @var \TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController $tsFrontendController */
		if (is_array($GLOBALS['TSFE']->config['INTincScript']))
		{
			$tsFrontendController          = $this->objectManager->get(\TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController::class, $GLOBALS["TYPO3_CONF_VARS"], $GLOBALS["TSFE"]->id, $GLOBALS["TSFE"]->type);
			$tsFrontendController->content = $cacheContent;
			$tsFrontendController->config  = $GLOBALS["TSFE"]->config;
			$tsFrontendController->INTincScript();
			$cacheContent = $tsFrontendController->content;
		}
		/**************************************************************/
		
		if (!is_null($this->arguments["hash"]))
			$hash = \MageDeveloper\Magecache\Utility\StringUtility::createCodeFromString( $this->arguments["hash"] );
		
		$this->_addToTemplateVariableContainer("cacheHash", $hash);
		$this->_addToTemplateVariableContainer("cacheLifetime", $lifetime);
		$this->_addToTemplateVariableContainer("cacheTags", $tags);
		
		// Checking if the content is already in cache
		if ($this->generalCacheService->has($hash))
		{
			// The content is already in the cache
			$this->_addToTemplateVariableContainer("cacheStatus", self::CACHE_RESTORED);

			if (isset($this->arguments["silent"]) && $this->arguments["silent"] == true)
				return "";
			
			return $this->_cachedContent( $this->generalCacheService->get($hash) );
		}	

		// Adding content to cache
		$this->generalCacheService->set($hash, $cacheContent, $tags, $lifetime);

		$this->_addToTemplateVariableContainer("cacheStatus", self::CACHED);
		
		if (isset($this->arguments["silent"]) && $this->arguments["silent"] == true)
			return "";
		
		return $cacheContent;
	}

}