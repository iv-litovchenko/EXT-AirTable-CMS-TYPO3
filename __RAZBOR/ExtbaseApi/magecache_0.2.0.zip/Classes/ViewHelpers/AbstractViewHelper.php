<?php
namespace MageDeveloper\Magecache\ViewHelpers;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
abstract class AbstractViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper
{
	/**
	 * GeneralCacheService
	 * 
	 * @var \MageDeveloper\Magecache\Service\Cache\GeneralCacheService
	 * @inject
	 */
	protected $generalCacheService;

	/**
	 * CacheSettingsService
	 * @var \MageDeveloper\Magecache\Service\Settings\CacheSettingsService
	 * @inject
	 */
	protected $cacheSettingsService;

	/**
	 * HashService
	 * @var \TYPO3\CMS\Extbase\Security\Cryptography\HashService
	 * @inject
	 */
	protected $hashService;

	/**
	 * Render Method
	 *
	 * @return void
	 */
	public function render()
	{
		return;
	}
}