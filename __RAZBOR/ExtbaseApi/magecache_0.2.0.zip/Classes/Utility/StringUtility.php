<?php
namespace MageDeveloper\Magecache\Utility;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class StringUtility
{
	/**
	 * Possible string dividers
	 *
	 * @var array
	 */
	protected static $dividers = array(
		';',
		'/',
		'.',
		"\\",
		":",
		"-"
	);

	/**
	 * Gets exploded and trimmed values by
	 * a separated string
	 *
	 * @param string $string String to separate
	 * @param array $allowedSeparators List of allowed separators
	 * @return array
	 */
	public static function explodeSeparatedString($string, $allowedSeparators = array())
	{
		if (strlen($string))
		{
			$dividers = self::$dividers;
		
			if (!empty($allowedSeparators))
				$dividers = $allowedSeparators;
		
			// Check that the divider of the ids is comma separation
			foreach ($dividers as $divider) {
					$string = str_replace($divider, ',', $string);
			}

			$exploded = array_map('trim',explode(",",$string));

			return $exploded;
		}

		return array();
	}

	/**
	 * Creates a usage friendly code from a given string
	 *
	 * @param $string Entry string
	 * @return string
	 */
	public static function createCodeFromString($string)
	{
		$value = trim($string);
		$value = strtolower($value);
		$value = str_replace(" ","_", $value);

		$removable_values = array(
			";" 	=> 	"_",
			":" 	=> 	"_",
			"/" 	=> 	"_",
			"."		=>  "_",
			"ö" 	=> 	"oe",
			"ä" 	=> 	"ae",
			"ü" 	=> 	"ue",
			"," 	=> 	"_",
			"__" 	=> 	"_",
			"___" 	=> 	"_",
		);

		//$value = preg_replace('/[^a-zA-Z0-9_]/u', '_', $value);
		$value = strtr($value, $removable_values);

		return $value;
	}

}