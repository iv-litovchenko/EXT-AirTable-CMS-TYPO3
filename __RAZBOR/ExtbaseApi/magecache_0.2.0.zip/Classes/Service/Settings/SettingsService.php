<?php
namespace MageDeveloper\Magecache\Service\Settings;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class SettingsService implements \TYPO3\CMS\Core\SingletonInterface
{
	/**
	 * @var mixed
	 */
	protected $settings = null;

	/**
	 * @var mixed
	 */
	protected $configuration = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface
	 * @inject
	 */
	protected $configurationManager;

	/**
	 * Content Object Renderer
	 * @var \TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer
	 * @inject
	 */
	protected $contentObjectRenderer;

	/**
	 * Returns all settings.
	 *
	 * @param string $extensionName Extension Key
	 * @param string $pluginName Plugin Name
	 * @return array
	 */
	public function getSettings($extensionName = null, $pluginName = null)
	{
		if ($this->settings === NULL)
		{
			$this->settings = $this->configurationManager->getConfiguration(
				\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_SETTINGS,
				$extensionName,
				$pluginName
			);
		}
		return $this->settings;
	}

	/**
	 * Returns configuration.
	 *
	 * @param string $extensionName Extension Key
	 * @param string $pluginName Plugin Name
	 * @return array
	 */
	public function getFullConfiguration($extensionName = null, $pluginName = null)
	{
		if ($this->configuration === NULL)
		{
			$this->configuration = $this->configurationManager->getConfiguration(
				\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT,
				$extensionName,
				$pluginName
			);

		}

		return $this->configuration;
	}

	/**
	 * Sets the configuration
	 *
	 * @param array $configuration
	 * @return void
	 */
	public function setConfiguration(array $configuration)
	{
		$this->configuration = $configuration;
	}

	/**
	 * Get configuration setting
	 *
	 * @param string $extensionName Name of the extension
	 * @param string $path Path to configuration
	 * @return mixed
	 */
	public function getExtensionConfiguration($extensionName, $path)
	{
		$nodes = explode('.', $path);
		$fullConfiguration = $this->getFullConfiguration();

		$config = null;
		$current = 0;
		$depth = count($nodes);
		$config = $fullConfiguration["plugin."][$extensionName."."];

		while (is_array($config))
		{
			$node = ($current+1 < $depth)?$nodes[$current].'.':$nodes[$current];

			if(array_key_exists($node, $config))
			{
				$config = $config[$node];
				$current++;
			}
			else
			{
				if (array_key_exists($node.'.', $config))
				{
					$config = $config[$node];
				}
				else
				{
					$config = "";
				}

				break;
			}

		}

		return $config;
	}

	/**
	 * Gets a setting by code
	 *
	 * @param string $code Setting Code
	 * @return string|null
	 */
	public function getSettingByCode($code)
	{
		$settings = $this->getSettings();

		if (is_array($settings) && isset($settings[$code]))
		{
			return $settings[$code];
		}

		return null;
	}

}