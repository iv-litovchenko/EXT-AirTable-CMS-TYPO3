<?php
namespace MageDeveloper\Magecache\Service\Settings;

use \MageDeveloper\Magecache\Configuration\ExtensionConfiguration as Configuration;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class CacheSettingsService extends SettingsService
{
	/**
	 * Plugin Name
	 * @var string
	 */
	protected $extensionName;

	public function __construct()
	{
		$this->setExtensionName( "tx_" . Configuration::EXTENSION_KEY );
	}

	/**
	 * Sets the extension name
	 * 
	 * @param string $extensionName
	 * @return void
	 */
	public function setExtensionName($extensionName)
	{
		$this->extensionName = $extensionName;
	}

	/**
	 * Gets the extension name
	 * 
	 * @return string
	 */
	public function getExtensionName()
	{
		return $this->extensionName;
	}

	/**
	 * Gets the extension configuration
	 * by a given configuration pathj
	 * 
	 * @param string $path Path to the configuration
	 * @return string|null
	 */
	public function getConfiguration($path)
	{
		$extensionName = $this->getExtensionName();
		return $this->getExtensionConfiguration($extensionName, $path);
	}

	/**
	 * Gets the cache lifetime from the
	 * template configuration
	 * 
	 * @return int
	 */
	public function getCacheLifetime()
	{
		$path = "settings.cache_lifetime";
		return (int)$this->getConfiguration($path);
	}

}