<?php
namespace MageDeveloper\Magecache\Service\Cache;

use \MageDeveloper\Magecache\Configuration\ExtensionConfiguration as Configuration;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class GeneralCacheService extends CacheService
{
	/**
	 * Constructor
	 *
	 * @return GeneralCacheService
	 */
	public function __construct()
	{
		$this->setCacheName( Configuration::EXTENSION_KEY . "_cache" );
		$this->initializeCache();
	}
}