<?php
namespace MageDeveloper\Magecache\Service\Session;

use \MageDeveloper\Magecache\Configuration\ExtensionConfiguration as Configuration;

/**
 * MageDeveloper Magecache Extension
 * -----------------------------------
 *
 * @category    TYPO3 Extension
 * @package     MageDeveloper\Magecache
 * @author		Bastian Zagar
 * @copyright   Magento Developers / magedeveloper.de <kontakt@magedeveloper.de>
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class SessionService
{
	/**
	 * Prefix Key
	 * @var string
	 */
	protected $prefixKey = "tx_magecache";

	/**
	 * Sets the session prefix key
	 * 
	 * @param string $prefixKey
	 */
	public function setPrefixKey($prefixKey)
	{
		$this->prefixKey = $prefixKey;
	}

	/**
	 * Restores data from the session
	 * 
	 * @param string $key
	 * @return mixed
	 */
	protected function restoreFromSession($key) 
	{
		$sessionData = $GLOBALS['TSFE']->fe_user->getKey('ses', $this->prefixKey . $key);
		return unserialize($sessionData);
	}

	/**
	 * Writes data to the session
	 * 
	 * @param mixed $object Object to write to the session
	 * @param string $key Identifier for the session
	 * @return \MageDeveloper\Magecache\Service\Session\SessionService
	 */
	protected function writeToSession($object, $key) 
	{
		$sessionData = serialize($object);
		$GLOBALS['TSFE']->fe_user->setKey('ses', $this->prefixKey . $key, $sessionData);
		$GLOBALS['TSFE']->fe_user->storeSessionData();
		return $this;
	}

	/**
	 * Cleans a variable that is stored in the session
	 * 
	 * @param string $key
	 * @return \MageDeveloper\Magecache\Service\Session\SessionService
	 */
	protected function cleanUpSession($key) 
	{
		$GLOBALS['TSFE']->fe_user->setKey('ses', $this->prefixKey . $key, NULL);
		$GLOBALS['TSFE']->fe_user->storeSessionData();
		return $this;
	}


	/**
	 * Set/Get attribute wrapper
	 * @param string $method
	 * @param array $args
	 * @throws \Exception
	 * @return mixed
	 */
	public function __call($method, $args)
	{
		$key = $this->_underscore(substr($method,3));
		switch( substr($method, 0, 3) )
		{
			case "get":
				return $this->getData($key);
			case "set":
				return $this->setData($key, isset($args[0]) ? $args[0] : null);
			case "uns":
				return $this->unsetData($key);
			case "has":
				return $this->hasData($key);
		}

		throw new \Exception("Invalid method " . get_class($this) . "::" . $method . "(" . print_r($args, 1) . ")");
	}

	/**
	 * Converts field names for Setters and Getters
	 * @param string $name
	 * @return string
	 */
	protected function _underscore($name)
	{
		$result = strtolower(preg_replace("/(.)([A-Z])/", "$1_$2", $name));
		return $result;
	}

	/**
	 * Sets data to the session
	 * 
	 * @param string $key Session Identifier
	 * @param mixed $value The value to set
	 * @return \MageDeveloper\Magecache\Service\Session\SessionService
	 */
	public function setData($key, $value)
	{
		return $this->writeToSession($value, $key);
	}

	/**
	 * Gets data from the session
	 * 
	 * @param string $key Session Identifier
	 * @return mixed
	 */
	public function getData($key)
	{
		$data = $this->restoreFromSession($key);
		return $data;
	}

	/**
	 * Checks if a session value exists
	 * 
	 * @param string $key
	 * @return bool
	 */
	public function hasData($key)
	{
		$data = $this->restoreFromSession($key);
		return ($data)?true:false;
	}

	/**
	 * Unsets data from the session
	 * 
	 * @param string $key
	 * @return \MageDeveloper\Magecache\Service\Session\SessionService
	 */
	public function unsetData($key)
	{
		return $this->cleanUpSession($key);
	}

}